import React from "react";
import { BrowserRouter as Router, Route, Link, Switch }
	from "react-router-dom";
import './App.css';
import Vaishali from "./Vaishali";
import Pooja from "./Pooja";


function App() {
return (
	<body>
	<Router>
	<Switch>
		<Route exact path="/new/second"
			component={Vaishali}>
		</Route>
		<Route exact path="/new/first"
			component={Pooja}>
		</Route>
		<ul>
      <h1>Users</h1>
		<br />
		<li>
			<Link to="/new/first" target="_blank">
			Pooja
			</Link>
		</li>
		<br />
		<li>
			<Link to="/new/second" target="_blank">
			Vaishali
			</Link>
		</li>
		</ul>
	</Switch>
	</Router>
	</body>
);
}
export default App;
