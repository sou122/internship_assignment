import React from "react";

function Vaishali() {
return (
	<body>
		<h1>Details of Vaishali : </h1>
		<p>Name : Vaishali</p>
		<p>Email id : vaishali@gmail.com</p>
		<p>Phone no : 3214657890</p>
		<p><img src="https://cdn.pixabay.com/photo/2020/11/22/05/00/child-5765633__340.png" height="200" weight="200" /></p>
	</body>
);
}
export default Vaishali;
