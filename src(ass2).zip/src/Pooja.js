import React from "react";

function Pooja() {
return (
	<body>
		<h1>Details of Pooja : </h1>
		<p>Name : Pooja</p>
		<p>Email id : pooja@gmail.com</p>
		<p>Phone no : 1234567890</p>
		<p><img src="https://cdn.pixabay.com/photo/2021/08/12/13/13/girl-6540808__340.png" height="200" weight="200" /></p>
	</body>
	
);
}
export default Pooja;
